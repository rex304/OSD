package com.AutoAllocation.Osd.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.AutoAllocation.Osd.entity.BackOfficeUsers;
public interface BackOfficeUsersRepository extends JpaRepository<BackOfficeUsers, UUID>{

	@Query("select bou from BackOfficeUsers bou join BackOfficeUserSession s on bou.backOfficeUserId=s.backOfficeUserId \n"
			+ "where s.sessionId=:sessionId")
	BackOfficeUsers getUserBySessionId(UUID sessionId);

	
}