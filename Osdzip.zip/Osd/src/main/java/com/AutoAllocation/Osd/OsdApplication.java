package com.AutoAllocation.Osd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsdApplication {

	public static void main(String[] args) {
		SpringApplication.run(OsdApplication.class, args);
	}

}
