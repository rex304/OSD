package com.AutoAllocation.Osd.entity;

import java.util.Date;
import java.util.UUID;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "BackOfficeUserSessions")
public class BackOfficeUserSession {
	@Id
	UUID sessionId;
	Date createdOn;
	Date lastAccessedOn;
	Integer isvalid;
	UUID backOfficeUserId;


}
