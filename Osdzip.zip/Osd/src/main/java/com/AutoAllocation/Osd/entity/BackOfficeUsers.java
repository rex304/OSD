package com.AutoAllocation.Osd.entity;


import java.util.Date;

import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "BACKOFFICEUSERS")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class BackOfficeUsers {
	@Id
	UUID backOfficeUserId;
	String email;
	String password;
	Integer isActive;
	String role;
	Date createdOn;
	Integer aadharCardLastFourDigit;
	String empoyeeId;
	String firstName;
	String lastname;
	String middlename;
	Long mobileNumber;
	String organizationName;
	String societyId;
	Integer invalidLoginCount;
	Integer isResetPwdExpired;
	Date resetPwdDateTime;
	@Column(name="IS_MAKER_OR_CHECKER")
	String isMakerOrChecker;
	@Column(name ="VPN_PASSWORD")
	String vpnPassword;
//	@Column(name = "company_id")
	Integer companyId;
	Integer groupId;
	Integer roleId;

}
